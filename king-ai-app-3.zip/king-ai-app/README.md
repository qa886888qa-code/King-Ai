# King AI — installable AI assistant

A responsive React/Vite app with Google sign-in, a chat interface, markdown/code formatting, copy responses, dark/light theme, model selector, chat prompt starters, and a Supabase Edge Function for server-side AI requests.

## What is already configured
- Supabase project URL and publishable key are supplied in `.env.local` for this project.
- The Supabase `chat_messages` table with row-level security and the `ai-chat` Edge Function were created in the connected project in the earlier setup.
- Google OAuth client was created by you in Google Cloud and the Google provider was saved in Supabase, based on the guided setup.

## Required before AI replies can work
The deployed Supabase Edge Function requires `OPENAI_API_KEY` to be configured in **Supabase Dashboard → Edge Functions → Secrets**. This key is not included in the ZIP and must never be placed in frontend files. You need an OpenAI API account with API access/billing; a ChatGPT subscription is not the same as API billing.

## Run on a computer
1. Install Node.js 20 or newer.
2. Extract this ZIP.
3. Open a terminal inside the `king-ai-app` folder and run:
   ```bash
   npm install
   npm run dev
   ```
4. Open the local URL Vite prints.
5. For Google OAuth, add that local URL (typically `http://localhost:5173`) to Supabase **Authentication → URL Configuration → Redirect URLs**. In Google Cloud, the Authorized redirect URI must be the callback URL shown in Supabase's Google provider page.

## AI API key
In Supabase Dashboard → Edge Functions → Secrets, add:
- Name: `OPENAI_API_KEY`
- Value: your private OpenAI API key

The backend currently defaults to `gpt-5-mini`. Model availability depends on the API account. Do not share the key in chat or commit it into source control.

## Deploy as a website
Run `npm run build`. Upload the generated `dist` folder to a static host such as Vercel, Netlify, or Cloudflare Pages. Configure `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY` as build environment variables and add the deployed URL to Supabase Redirect URLs.

## Install on Android
After deploying to HTTPS, open the website in Chrome, tap the three-dot menu, then **Add to Home screen** / **Install app** (label varies by Chrome version).

## Honest limitations
- This is a capable AI chat app shell, not a claim to be more intelligent than every AI model. Intelligence depends on the AI model and account configured in the backend.
- This project does not include paid API credits, secret keys, image generation, voice, web search, file uploads, or long-term memory. Those require separate integrations and backend work.
- Current schema saves user/assistant messages securely by user ID, but it does not implement multiple independently reopenable conversation threads yet.
