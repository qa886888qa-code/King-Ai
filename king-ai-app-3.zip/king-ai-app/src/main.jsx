import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import DOMPurify from "dompurify";
import { marked } from "marked";
import {
  ArrowUp, Plus, Menu, X, Sparkles, MessageSquare, LogOut, Moon, Sun,
  Copy, Check, Trash2, PanelLeftClose, PanelLeft, Bot, UserRound, ChevronDown,
  Globe, Code2, Lightbulb, Image, Search, Settings2, ExternalLink, Zap
} from "lucide-react";
import { supabase } from "./supabase";
import "./styles.css";

marked.setOptions({ breaks: true, gfm: true });
const SUGGESTIONS = [
  {icon: Lightbulb, title:"Explain something", text:"Explain a difficult topic in simple words with examples."},
  {icon: Code2, title:"Write or fix code", text:"Help me write, understand, or debug code."},
  {icon: Globe, title:"Plan something", text:"Help me make a practical step-by-step plan."},
  {icon: Sparkles, title:"Be creative", text:"Give me 10 creative ideas for a project."}
];

function App() {
  const [session,setSession]=useState(null);
  const [authLoading,setAuthLoading]=useState(true);
  const [messages,setMessages]=useState([]);
  const [input,setInput]=useState("");
  const [busy,setBusy]=useState(false);
  const [sidebar,setSidebar]=useState(true);
  const [mobileSidebar,setMobileSidebar]=useState(false);
  const [dark,setDark]=useState(true);
  const [chats,setChats]=useState([]);
  const [activeChat,setActiveChat]=useState(null);
  const [model,setModel]=useState("gpt-5-mini");
  const [showModels,setShowModels]=useState(false);
  const [error,setError]=useState("");
  const [search,setSearch]=useState("");
  const bottomRef=useRef(null);
  const inputRef=useRef(null);

  useEffect(()=>{
    if(!supabase){setAuthLoading(false);return;}
    supabase.auth.getSession().then(({data})=>{setSession(data.session);setAuthLoading(false);});
    const {data:{subscription}}=supabase.auth.onAuthStateChange((_event,s)=>{setSession(s);setAuthLoading(false);});
    return ()=>subscription.unsubscribe();
  },[]);
  useEffect(()=>{if(session) loadChats(); else {setChats([]);setMessages([]);setActiveChat(null);}},[session?.user?.id]);
  useEffect(()=>{bottomRef.current?.scrollIntoView({behavior:"smooth"});},[messages,busy]);
  useEffect(()=>{document.documentElement.dataset.theme=dark?"dark":"light";},[dark]);

  async function signIn(){setError("");if(!supabase){setError("Setup needed: add your Supabase URL and publishable key to .env.local, then restart the app.");return;}
    const {error}=await supabase.auth.signInWithOAuth({provider:"google",options:{redirectTo:window.location.origin}});if(error)setError(error.message);}
  async function signOut(){await supabase?.auth.signOut();setSession(null);}
  async function loadChats(){if(!supabase||!session)return;const {data,error}=await supabase.from("chat_messages").select("id,role,content,created_at").order("created_at",{ascending:true}).limit(300);if(error){console.warn(error.message);return;}
    // Existing schema stores messages, so group into sessions by date as a lightweight fallback.
    const rows=data||[];setChats(rows.length?[{id:"history",title:"Saved conversation",count:rows.length}]:[]);}
  async function persist(role,content){if(!supabase||!session)return;const {error}=await supabase.from("chat_messages").insert({user_id:session.user.id,role,content});if(error)console.warn("Could not save chat:",error.message);}
  function newChat(){setMessages([]);setActiveChat(null);setError("");setMobileSidebar(false);inputRef.current?.focus();}
  async function send(text=input){const prompt=text.trim();if(!prompt||busy)return;setInput("");setError("");setMessages(prev=>[...prev,{role:"user",content:prompt}]);setBusy(true);
    await persist("user",prompt);
    try{
      if(!supabase||!session)throw new Error("Please sign in first.");
      const history=[...messages,{role:"user",content:prompt}].slice(-16).map(m=>({role:m.role,content:m.content}));
      const {data,error}=await supabase.functions.invoke("ai-chat",{body:{messages:history,model,system:"You are King AI, a helpful, careful, capable AI assistant. Respond in the user's language. Be honest about uncertainty. Use clear structure and useful examples. Never claim capabilities or actions you do not have."}});
      if(error)throw new Error(error.message||"AI request failed.");
      if(data?.error)throw new Error(data.error);
      if(!data?.text)throw new Error("The AI returned an empty response. Check your AI API key and function logs.");
      setMessages(prev=>[...prev,{role:"assistant",content:data.text}]);await persist("assistant",data.text);
      setChats([{id:"history",title:prompt.slice(0,36),count:messages.length+2}]);
    }catch(e){setError(e.message||"Something went wrong.");}finally{setBusy(false);inputRef.current?.focus();}
  }
  async function copyText(t){try{await navigator.clipboard.writeText(t);}catch{setError("Clipboard access was blocked by your browser.");}}
  const rendered=(s)=>({__html:DOMPurify.sanitize(marked.parse(s||""))});
  const filteredChats=useMemo(()=>chats.filter(c=>c.title.toLowerCase().includes(search.toLowerCase())),[chats,search]);

  if(authLoading)return <div className="loading"><div className="brand-mark"><Sparkles/></div><p>Loading King AI…</p></div>;
  if(!session)return <div className="auth-page"><div className="auth-glow"/><div className="auth-card"><div className="brand-mark large"><Sparkles size={28}/></div><div className="eyebrow">YOUR PERSONAL AI</div><h1>Meet <span>King AI</span></h1><p className="auth-copy">Think clearly. Create faster. Learn anything. Your AI assistant is ready when you are.</p><div className="feature-pills"><span><Zap size={14}/> Smart answers</span><span><MessageSquare size={14}/> Chat history</span><span><Code2 size={14}/> Coding help</span></div><button className="google-btn" onClick={signIn}><GoogleIcon/> Continue with Google</button>{error&&<div className="error">{error}</div>}<p className="fineprint">Sign in securely with Google. Your account is managed by Supabase Auth.</p><div className="auth-foot">KING AI <span>•</span> BUILT FOR YOUR IDEAS</div></div></div>;

  return <div className={`app ${sidebar?"with-sidebar":""}`}>
    {mobileSidebar&&<div className="mobile-scrim" onClick={()=>setMobileSidebar(false)}/>}
    <aside className={`sidebar ${sidebar?"":"collapsed"} ${mobileSidebar?"mobile-open":""}`}>
      <div className="side-top"><button className="brand" onClick={newChat}><span className="brand-mark"><Sparkles size={18}/></span>{sidebar&&<span>King <b>AI</b></span>}</button><button className="icon-btn desktop-only" title="Collapse sidebar" onClick={()=>setSidebar(!sidebar)}>{sidebar?<PanelLeftClose size={18}/>:<PanelLeft size={18}/>}</button><button className="icon-btn mobile-only" onClick={()=>setMobileSidebar(false)}><X size={19}/></button></div>
      <button className="new-chat" onClick={newChat}><Plus size={18}/>{sidebar&&"New chat"}</button>
      {sidebar&&<div className="history-area"><div className="section-label">YOUR CHATS</div><div className="search-box"><Search size={15}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search chats"/></div>{filteredChats.length?filteredChats.map(c=><button className="history-item" key={c.id} onClick={()=>{setMessages([]);setMobileSidebar(false);setError("Chat history is stored securely, but reopening individual conversations needs a conversation-ID schema.");}}><MessageSquare size={15}/><span>{c.title}</span></button>):<div className="empty-history">Your conversations will appear here.</div>}</div>}
      <div className="side-bottom"><div className="user-card"><div className="avatar">{(session.user.email||"K")[0].toUpperCase()}</div>{sidebar&&<div className="user-info"><strong>{session.user.user_metadata?.full_name||"King AI user"}</strong><small>{session.user.email}</small></div>}<button className="icon-btn" title="Sign out" onClick={signOut}><LogOut size={17}/></button></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><div className="top-left"><button className="icon-btn mobile-only" onClick={()=>setMobileSidebar(true)}><Menu size={20}/></button><div className="model-wrap"><button className="model-button" onClick={()=>setShowModels(!showModels)}><span className="model-dot"/>{model==="gpt-5-mini"?"King AI":model}<ChevronDown size={15}/></button>{showModels&&<div className="model-menu"><div className="menu-title">AI model</div>{[["gpt-5-mini","Fast · balanced"],["gpt-4.1-mini","Compact · capable"]].map(([m,d])=><button key={m} onClick={()=>{setModel(m);setShowModels(false);}}><span><b>{m}</b><small>{d}</small></span>{model===m&&<Check size={16}/>}</button>)}<small className="menu-note">Model availability depends on your API account.</small></div>}</div></div><div className="top-actions"><span className="secure-label"><span className="green-dot"/> Private session</span><button className="icon-btn" title="Toggle theme" onClick={()=>setDark(!dark)}>{dark?<Sun size={18}/>:<Moon size={18}/>}</button><button className="icon-btn" title="New chat" onClick={newChat}><Plus size={19}/></button></div></header>
      <section className="conversation">
        {messages.length===0?<div className="welcome"><div className="welcome-symbol"><Sparkles size={27}/></div><div className="eyebrow">WELCOME TO KING AI</div><h1>What can I help you <span>with?</span></h1><p>Ask a question, explore an idea, or build something extraordinary.</p><div className="suggestions">{SUGGESTIONS.map(({icon:Icon,title,text})=><button className="suggestion" key={title} onClick={()=>send(text)}><span className="suggestion-icon"><Icon size={18}/></span><span><b>{title}</b><small>{text}</small></span><ArrowUp size={15} className="suggestion-arrow"/></button>)}</div></div>:<div className="message-list">{messages.map((m,i)=><article className={`message ${m.role}`} key={i}><div className={`message-avatar ${m.role}`}>{m.role==="assistant"?<Sparkles size={17}/>:<UserRound size={17}/>}</div><div className="message-body"><div className="message-name">{m.role==="assistant"?"King AI":"You"}</div><div className="markdown" dangerouslySetInnerHTML={rendered(m.content)}/>{m.role==="assistant"&&<div className="message-tools"><button onClick={()=>copyText(m.content)}><Copy size={14}/> Copy</button></div>}</div></article>)}{busy&&<article className="message assistant"><div className="message-avatar assistant"><Sparkles size={17}/></div><div className="message-body"><div className="message-name">King AI</div><div className="typing"><i/><i/><i/><span>Thinking…</span></div></div></article>}<div ref={bottomRef}/></div>}
      </section>
      <div className="composer-wrap"><div className="composer-shell"><textarea ref={inputRef} rows="1" value={input} placeholder="Message King AI…" onChange={e=>{setInput(e.target.value);e.target.style.height="auto";e.target.style.height=Math.min(e.target.scrollHeight,180)+"px";}} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}}}/><div className="composer-bottom"><div className="composer-hint"><span>King AI can make mistakes. Verify important information.</span></div><button className="send-btn" disabled={!input.trim()||busy} onClick={()=>send()} title="Send message">{busy?<span className="spinner"/>:<ArrowUp size={19}/>}</button></div></div>{error&&<div className="error inline-error">{error}</div>}<div className="below-composer">Powered by your configured AI API <span>•</span> Shift + Enter for a new line</div></div>
    </main>
  </div>;
}
function GoogleIcon(){return <svg viewBox="0 0 48 48" width="20" height="20" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.01 13.22l7.98 6.19C11.92 13.72 17.47 9.5 24 9.5z" transform="translate(0 4)"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.76 7.18l7.73 6C44.42 37.98 46.98 31.88 46.98 24.55z"/><path fill="#FBBC05" d="M10.53 28.59a14.4 14.4 0 0 1 0-9.18l-7.98-6.19a24 24 0 0 0 0 21.56l7.98-6.19z" transform="translate(0 4)"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.91-5.8l-7.73-6c-2.15 1.45-4.92 2.3-8.18 2.3-6.53 0-12.08-4.22-14.01-9.91l-7.98 6.19C6.51 43.62 14.62 48 24 48z" transform="translate(0 -3)"/></svg>}
createRoot(document.getElementById("root")).render(<App/>);
